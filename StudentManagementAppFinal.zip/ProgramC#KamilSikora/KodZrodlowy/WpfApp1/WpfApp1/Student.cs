﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WpfApp1
{
    public class Student
    {
        private int studentId;
        private string name;
        private string surname;
        private int indexNumber;
        private List<Grades>? grades;
        private string gradesString;
        private string dateOfBirth;
        public int StudentId { get { return studentId; } set { studentId = value; } }
        public string Name { get { return name; } set { name = value; } }
        public string Surname { get { return surname; } set { surname = value; } }
        public int IndexNumber { get { return indexNumber; } set { indexNumber = value; } }
        public List<Grades>? Grades { get { return grades; } set { grades = value; } }
        public string GradesString { get { return gradesString; } set { gradesString = value; } }
        public string DateOfBirth { get { return dateOfBirth; } set { dateOfBirth = value; } }
        public Student()
        {
            this.grades = new List<Grades>();
        }
        public void PrintGrades()
        {
            this.GradesString = "";
            for (int i = 0; i < Grades.Count(); i++)
            {
                GradesString = GradesString + this.Grades[i].Grade.ToString() + "; ";
            }
            if (Grades.Count() == 0)
                this.GradesString = "Brak ocen";
        }
    }
}
