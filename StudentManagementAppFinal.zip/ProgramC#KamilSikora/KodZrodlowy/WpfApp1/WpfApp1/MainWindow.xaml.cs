﻿using System;
using System.Windows;
using System.Linq;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using System.Collections;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<Student> students = new ObservableCollection<Student>(DataAccess.LoadStudents());
        public ObservableCollection<Student> Students
        {
            get { return students; }
            set { students = value; }
        }
        public IList selectedItems;

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void addStudentButton_Click(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            window1.Owner = this;
        }

        private void findStudentButton_Click(object sender, RoutedEventArgs e)
        {
            Students = new ObservableCollection<Student>(DataAccess.SearchStudents(findStudentTextBox.Text.ToString()));
            StudentsDataGrid.ItemsSource = Students;
        }

        private void addGrade_Click(object sender, RoutedEventArgs e)
        {
            if (StudentsDataGrid.SelectedItems.Count == 0)
                MessageBox.Show("Błąd! Najpierw proszę zaznaczyć studenta!");
            else
            {
                Window2 window2 = new Window2(StudentsDataGrid.SelectedItems);
                window2.Show();
                window2.Owner = this;
            }
        }

        private void removeStudent(object sender, RoutedEventArgs e)
        {
            selectedItems = StudentsDataGrid.SelectedItems;
            if (selectedItems != null)
            {
                try
                {
                    for (int i = 0; i < selectedItems.Count; i++)
                    {
                        var selectedItem = selectedItems[i] as Student;
                        DataAccess.RemoveStudent(selectedItem);
                    }
                    if (selectedItems.Count == 0)
                        MessageBox.Show("Błąd! Najpierw należy zaznaczyć rekordy!");
                    else
                        MessageBox.Show("Usuwanie zakończone powodzeniem!");
                }
                catch (Exception exception)
                {
                    MessageBox.Show("Błąd! " + exception.Message);
                }
                StudentsDataGrid.ItemsSource = new ObservableCollection<Student>(DataAccess.LoadStudents());
            }
        }

        private void StudentsDataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            SaveEditedButton.IsEnabled = true;
        }

        private void SaveEditedButton_Click(object sender, RoutedEventArgs e)
        {
            SaveEditedButton.IsEnabled = false;
            var copyOfStudents = new ObservableCollection<Student>(DataAccess.LoadStudents());
            bool poprawne = true;
            try
            {
                for (int i = 0; i < Students.Count(); i++)
                {
                    Students[i].DateOfBirth = Convert.ToDateTime(Students[i].DateOfBirth).ToString();
                    Students[i].DateOfBirth = Students[i].DateOfBirth.Substring(0, Students[i].DateOfBirth.LastIndexOf(" ") + 1);
                    if (Students[i].Name == "" || Students[i].Surname == "" || (Students[i].IndexNumber.ToString() == "" ||
                        Students[i].IndexNumber.ToString().Length!=6 || Students[i].IndexNumber<0)
                        || Students[i].DateOfBirth == "")
                    {
                        poprawne = false;
                        break;
                    }
                    if (!copyOfStudents[i].Equals(Students[i]))
                        DataAccess.EditStudent(Students[i]);
                }
                if (poprawne == false)
                {
                    MessageBox.Show("Błąd! Dane w niepoprawnym formacie!");
                    Students = copyOfStudents;
                }
                else
                    MessageBox.Show("Sukces! Dane zostały zaktualizowane!");
            }
            catch(Exception exception)
            {
                MessageBox.Show("Błąd! "+exception.Message);
                Students = copyOfStudents;
            }
            Students = new ObservableCollection<Student>(DataAccess.LoadStudents());
            StudentsDataGrid.ItemsSource = Students;
        }

        private void StudentsDataGrid_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
        {
            SaveEditedButton.IsEnabled = false;
        }
    }
}
