﻿using System;
using System.Runtime;
using System.Windows;

namespace WpfApp1
{
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void addNewStudentConfirmButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Student student = new Student();
                student.Name = nameTextBox.Text.ToString();
                if (student.Name == "")
                    student.Name = null;
                student.Surname = surnameTextBox.Text.ToString();
                if (student.Surname == "")
                    student.Surname = null;
                if (studentIdTextBox.Text.Length != 6 || Convert.ToInt32(studentIdTextBox.Text)<0)
                    studentIdTextBox.Text = "";
                student.IndexNumber = Convert.ToInt32(studentIdTextBox.Text);
                var dateOfBirth = Convert.ToDateTime(dateOfBirthTextBox.Text.ToString());
                student.DateOfBirth = dateOfBirth.ToString();
                student.DateOfBirth = student.DateOfBirth.Substring(0, student.DateOfBirth.LastIndexOf(" ") + 1);
                DataAccess.AddStudent(student);
                ((MainWindow)this.Owner).StudentsDataGrid.ItemsSource = DataAccess.LoadStudents();
                MessageBox.Show("Sukces! Dodano nowego studenta!");
                Close();
            } catch(Exception exception)
            {
                if (exception.Message=="Input string was not in a correct format.")
                    MessageBox.Show("Błąd! Wartość została przedstawiona w złym formacie!");
                else
                    MessageBox.Show("Błąd! " + exception.Message);
            }
        }
    }
}
