﻿using Dapper;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Linq;

namespace WpfApp1
{
    public class DataAccess
    {
        public static List<Student> LoadStudents()
        {
            using (IDbConnection cnn = new SQLiteConnection(
                ConfigurationManager.ConnectionStrings["Default"].ConnectionString))
            {
                var sqlquery = cnn.Query<Student>("select * from Students");
                List<Student> students = sqlquery.ToList();
                var sqlquery2 = cnn.Query<Grades>("select * from Grades");
                List<Grades> grades = sqlquery2.ToList(); 
                for (int i=0;i<students.Count();i++)
                {
                    for (int j=0;j<grades.Count();j++)
                    {
                        if (grades[j].StudentId == students[i].StudentId)
                        {
                            students[i].Grades.Add(grades[j]);
                        }
                    }
                    students[i].PrintGrades();
                }
                return students;
            }
        }
        public static List<Student> SearchStudents(string search)
        {
            using (IDbConnection cnn = new SQLiteConnection(
                ConfigurationManager.ConnectionStrings["Default"].ConnectionString))
            {
                var sqlquery = cnn.Query<Student>("select * from Students where StudentId like \"%" + search + "%\" or Name like \"%" + search + "%\" or Surname like \"%" + search + "%\" or DateOfBirth like \"%" + search + "%\"");
                List<Student> students = sqlquery.ToList();
                var sqlquery2 = cnn.Query<Grades>("select * from Grades");
                List<Grades> grades = sqlquery2.ToList();
                for (int i = 0; i < students.Count(); i++)
                {
                    for (int j = 0; j < grades.Count(); j++)
                    {
                        if (grades[j].StudentId == students[i].StudentId)
                        {
                            students[i].Grades.Add(grades[j]);
                        }
                    }
                    students[i].PrintGrades();
                }
                return students;
            }
        }
        public static void AddStudent(Student student)
        {
            using (IDbConnection cnn = new SQLiteConnection(
                ConfigurationManager.ConnectionStrings["Default"].ConnectionString))
            {
                cnn.Execute("insert into Students (IndexNumber, Name, Surname, DateOfBirth) values(@IndexNumber, @Name, @Surname, @DateOfBirth)", student);
            }
        }
        public static void EditStudent(Student student)
        {
            using (IDbConnection cnn = new SQLiteConnection(
                ConfigurationManager.ConnectionStrings["Default"].ConnectionString))
            {
                cnn.Execute("update Students SET IndexNumber = @IndexNumber, Name = @Name, Surname = @Surname, DateOfBirth = @DateOfBirth where StudentId = @StudentId", student);
            }
        }
        public static void RemoveStudent(Student student)
        {
            using (IDbConnection cnn = new SQLiteConnection(
                ConfigurationManager.ConnectionStrings["Default"].ConnectionString))
            {
                cnn.Execute("delete from Grades where StudentId="+student.IndexNumber);
                cnn.Execute("delete from Students where StudentId="+student.StudentId);
            }
        }
        public static void AddGrade(Grades grade, int studentId)
        {
            using (IDbConnection cnn = new SQLiteConnection(
                ConfigurationManager.ConnectionStrings["Default"].ConnectionString))
            {
                cnn.Execute("insert into Grades (Grade, SchoolSubject, DateOfGrade, StudentId) values("+grade.Grade+",\""+grade.SchoolSubject+"\",\""+grade.DateOfGrade+"\","+studentId+")");
            }
        }
    }
}
