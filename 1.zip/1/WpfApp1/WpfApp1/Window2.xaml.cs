﻿using System;
using System.Windows;
using System.Collections;

namespace WpfApp1
{
    public partial class Window2 : Window
    {
        private IList selectedItems;
        public IList SelectedItems { get { return selectedItems; } set { selectedItems = value; } }
        
        public Window2(IList selectedItems)
        {
            InitializeComponent();
            this.selectedItems = SelectedItems;
            if (selectedItems.Count != 0)
            {
                var selectedItem = selectedItems[0] as Student;
                studentIdTextBox.Text = selectedItem.IndexNumber.ToString();
            }
        }

        private void addNewGradeConfirmButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Grades grade = new Grades();
                if (Convert.ToInt32(gradeTextBox.Text) > 5 || Convert.ToInt32(gradeTextBox.Text) < 1)
                    gradeTextBox.Text = "";
                grade.Grade = Convert.ToInt32(gradeTextBox.Text);
                grade.SchoolSubject = schoolSubjectTextBox.Text.ToString();
                var dateOfGrade = Convert.ToDateTime(dateOfGradeTextBox.Text.ToString());
                grade.DateOfGrade = dateOfGrade.ToString();
                grade.DateOfGrade = grade.DateOfGrade.Substring(0, grade.DateOfGrade.LastIndexOf(" ") + 1);
                int studentId = Convert.ToInt32(studentIdTextBox.Text);
                DataAccess.AddGrade(grade, studentId);
                ((MainWindow)this.Owner).StudentsDataGrid.ItemsSource = DataAccess.LoadStudents();
                MessageBox.Show("Sukces! Wystawiono nową ocenę!");
                Close();
            } catch(Exception exception)
            {
                if (exception.Message == "Input string was not in a correct format.")
                    MessageBox.Show("Błąd! Wartość została przedstawiona w złym formacie!");
                else
                    MessageBox.Show("Błąd! " + exception.Message);
            }
        }
    }
}
