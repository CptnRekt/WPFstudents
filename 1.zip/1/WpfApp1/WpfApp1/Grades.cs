﻿using System;
namespace WpfApp1
{
    public class Grades
    {
        private int id;
        private int grade;
        private string schoolSubject;
        private string dateOfGrade;
        private int studentId;
        public int Id {  get { return id; } set { id = value; } }
        public int Grade { get { return grade; } set { grade = value; } }
        public string SchoolSubject { get { return schoolSubject; } set { schoolSubject = value; } }
        public string DateOfGrade { get { return dateOfGrade; } set { dateOfGrade = value; } }
        public int StudentId { get { return studentId; } set { studentId = value; } }
    }
}
